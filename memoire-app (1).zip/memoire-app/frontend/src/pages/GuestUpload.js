import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Upload, Camera, Heart, CheckCircle, X, Video, MessageSquare, ArrowRight, Image } from 'lucide-react';
import api from '../utils/api';
import { Button, Input, Textarea, Spinner } from '../components/UI';

/* ── Preview grid item ──────────────────────────────────────────────────── */
const PreviewItem = ({ file, onRemove }) => {
  const [src, setSrc] = useState(null);
  useEffect(() => {
    if (!file.type.startsWith('image/')) return;
    const url = URL.createObjectURL(file);
    setSrc(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  return (
    <motion.div initial={{opacity:0,scale:.9}} animate={{opacity:1,scale:1}} exit={{opacity:0,scale:.9}}
      className="aspect-square rounded-[var(--r-sm)] overflow-hidden bg-[var(--stone-100)] relative group">
      {src ? (
        <img src={src} alt="" className="w-full h-full object-cover"/>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-[var(--stone-300)]">
          <Video size={22}/>
        </div>
      )}
      <button onClick={() => onRemove(file)}
        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
        <X size={11}/>
      </button>
    </motion.div>
  );
};

/* ── Guest Upload Page ──────────────────────────────────────────────────── */
export default function GuestUpload() {
  const { token } = useParams();
  const [event,   setEvent]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  const [step, setStep]   = useState('name'); // name | upload | done
  const [name, setName]   = useState('');
  const [files, setFiles] = useState([]);
  const [msg,   setMsg]   = useState('');
  const [busy,  setBusy]  = useState(false);
  const [progress, setProg] = useState(0);
  const [uploadErr, setUploadErr] = useState('');

  useEffect(() => {
    api.get(`/public/events/${token}`)
      .then(r => {
        setEvent(r.data);
        if (!r.data.settings?.require_name) setStep('upload');
      })
      .catch(e => setError(e.response?.data?.error || 'Event not found'))
      .finally(() => setLoading(false));
  }, [token]);

  const onDrop = useCallback(accepted => {
    setFiles(p => [...p, ...accepted].slice(0, 20));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg':[], 'image/png':[], 'image/heic':[], 'image/heif':[], 'image/webp':[],
      'video/mp4':[], 'video/quicktime':[],
    },
    multiple: true,
    maxSize: 200 * 1024 * 1024,
  });

  const removeFile = f => setFiles(p => p.filter(x => x !== f));

  const doUpload = async () => {
    if (!files.length && !msg.trim()) return;
    setBusy(true);
    setUploadErr('');
    const fd = new FormData();
    if (name.trim()) fd.append('uploader_name', name.trim());
    if (msg.trim())  fd.append('message', msg.trim());
    files.forEach(f => fd.append('files', f));
    try {
      await api.post(`/public/events/${token}/media`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: e => setProg(Math.round(e.loaded / e.total * 100)),
      });
      setStep('done');
    } catch (err) {
      setUploadErr(err.response?.data?.error || 'Upload failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const reset = () => { setFiles([]); setMsg(''); setProg(0); setUploadErr(''); setStep('upload'); };

  const accent = event?.settings?.primary_color ?? '#c9a96e';

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--stone-50)]">
      <Spinner size={44}/>
    </div>
  );

  if (error && !event) return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center p-8 bg-[var(--stone-50)]">
      <Camera size={40} className="text-[var(--stone-300)] mb-4"/>
      <h2 className="font-display text-2xl mb-2">Not Found</h2>
      <p className="text-[var(--stone-500)]">{error}</p>
    </div>
  );

  /* ── Slide variants ──────────────────────────────────────────────────── */
  const slide = {
    initial: { opacity:0, x:24 },
    animate: { opacity:1, x:0 },
    exit:    { opacity:0, x:-24 },
  };

  return (
    <div className="min-h-screen bg-[var(--stone-50)] flex flex-col">
      {/* Hero banner */}
      <div className="relative overflow-hidden text-center py-14 px-6 select-none"
        style={{ background: `linear-gradient(150deg, ${accent}18 0%, ${accent}35 100%)` }}>
        <div className="absolute top-4  left-10  text-4xl opacity-20 font-display italic">♡</div>
        <div className="absolute bottom-4 right-12 text-3xl opacity-15 font-display">✦</div>
        <div className="absolute top-6  right-20 text-2xl opacity-10">♡</div>
        <motion.div initial={{opacity:0,y:-8}} animate={{opacity:1,y:0}} transition={{duration:.5}}>
          <h1 className="font-display text-4xl md:text-5xl tracking-tight">{event?.title}</h1>
          {event?.description && (
            <p className="text-[var(--stone-600)] mt-3 max-w-md mx-auto text-sm leading-relaxed">{event.description}</p>
          )}
        </motion.div>
      </div>

      {/* Content */}
      <main className="flex-1 flex flex-col items-center px-5 py-8">
        <div className="w-full max-w-md">
          <AnimatePresence mode="wait">
            {/* ── Step 1: Name ──────────────────────────────────────────── */}
            {step === 'name' && (
              <motion.div key="name" {...slide} transition={{duration:.3}}>
                <div className="text-center mb-8">
                  <div className="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center"
                    style={{ background: `${accent}25` }}>
                    <Heart size={22} style={{ color: accent }}/>
                  </div>
                  <h2 className="font-display text-2xl mb-1.5">What's your name?</h2>
                  <p className="text-[var(--stone-500)] text-sm">So we know who shared these memories ✨</p>
                </div>

                <form onSubmit={e => { e.preventDefault(); if(name.trim()) setStep('upload'); }}
                  className="flex flex-col gap-4">
                  <Input
                    placeholder="Your name"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required autoFocus
                    className="text-center text-lg"
                  />
                  <Button type="submit" size="lg" className="w-full" disabled={!name.trim()}
                    style={{ background: accent, borderColor: accent }}>
                    Continue <ArrowRight size={17}/>
                  </Button>
                </form>
              </motion.div>
            )}

            {/* ── Step 2: Upload ───────────────────────────────────────── */}
            {step === 'upload' && (
              <motion.div key="upload" {...slide} transition={{duration:.3}} className="flex flex-col gap-5">
                {name && (
                  <p className="text-center text-[var(--stone-500)] text-sm">
                    Hi <strong className="text-[var(--stone-900)]">{name}</strong>! Share your favourite moments.
                  </p>
                )}

                {/* Dropzone */}
                <div {...getRootProps()} className={`
                  border-2 border-dashed rounded-[var(--r-xl)] p-8 text-center cursor-pointer transition-all
                  ${isDragActive
                    ? 'border-[var(--gold-400)] bg-amber-50'
                    : 'border-[var(--stone-200)] hover:border-[var(--stone-300)] hover:bg-[var(--stone-100)]'}
                `}>
                  <input {...getInputProps()}/>
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-14 h-14 rounded-full flex items-center justify-center"
                      style={{ background: `${accent}20` }}>
                      <Upload size={22} style={{ color: accent }}/>
                    </div>
                    <div>
                      <p className="font-medium text-[var(--stone-800)]">
                        {isDragActive ? 'Drop your photos here!' : 'Tap to add photos & videos'}
                      </p>
                      <p className="text-xs text-[var(--stone-400)] mt-1">
                        JPEG, PNG, HEIC, MP4, MOV · up to 200 MB · max 20 files
                      </p>
                    </div>
                  </div>
                </div>

                {/* Previews */}
                {files.length > 0 && (
                  <div>
                    <p className="text-xs text-[var(--stone-500)] mb-2">{files.length} file{files.length!==1?'s':''} selected</p>
                    <div className="grid grid-cols-4 gap-1.5">
                      <AnimatePresence>
                        {files.map((f,i) => <PreviewItem key={`${f.name}-${i}`} file={f} onRemove={removeFile}/>)}
                      </AnimatePresence>
                    </div>
                  </div>
                )}

                {/* Guestbook message */}
                <div>
                  <div className="flex items-center gap-1.5 mb-2 text-[var(--stone-500)]">
                    <MessageSquare size={13}/>
                    <p className="text-xs font-medium">Leave a message (optional)</p>
                  </div>
                  <Textarea
                    placeholder="A heartfelt wish, a favourite memory, or just a hello…"
                    value={msg}
                    onChange={e => setMsg(e.target.value)}
                    rows={3}
                  />
                </div>

                {uploadErr && (
                  <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-[var(--r-md)] px-4 py-3 text-sm">
                    {uploadErr}
                  </div>
                )}

                {/* Progress */}
                {busy && (
                  <div>
                    <div className="flex justify-between text-xs text-[var(--stone-400)] mb-1">
                      <span>Uploading…</span><span>{progress}%</span>
                    </div>
                    <div className="h-1.5 bg-[var(--stone-100)] rounded-full overflow-hidden">
                      <motion.div className="h-full rounded-full" style={{ background: accent }}
                        initial={{ width:0 }} animate={{ width:`${progress}%` }}/>
                    </div>
                  </div>
                )}

                <Button onClick={doUpload} size="lg" loading={busy}
                  className="w-full" disabled={!files.length && !msg.trim()}
                  style={{ background: accent }}>
                  <Upload size={17}/>
                  Share {files.length > 0 ? `${files.length} file${files.length!==1?'s':''}` : 'Message'}
                </Button>

                {event?.settings?.allow_public_view && (
                  <p className="text-center text-xs text-[var(--stone-400)]">
                    <a href={`/e/${token}/gallery`} className="hover:underline hover:text-[var(--stone-700)]">
                      View the gallery →
                    </a>
                  </p>
                )}
              </motion.div>
            )}

            {/* ── Step 3: Done ─────────────────────────────────────────── */}
            {step === 'done' && (
              <motion.div key="done" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}}
                className="flex flex-col items-center text-center gap-6 py-8">
                <motion.div initial={{scale:0}} animate={{scale:1}} transition={{type:'spring',stiffness:200,delay:.1}}
                  className="w-20 h-20 rounded-full flex items-center justify-center"
                  style={{ background: `${accent}25` }}>
                  <CheckCircle size={40} style={{ color: accent }}/>
                </motion.div>
                <div>
                  <h2 className="font-display text-3xl mb-2">Thank you!</h2>
                  <p className="text-[var(--stone-500)]">
                    Your {files.length > 0 ? `${files.length} file${files.length!==1?'s':''}` : 'message'}{' '}
                    {files.length !== 1 ? 'have' : 'has'} been added to the album.
                  </p>
                </div>
                <div className="flex flex-col gap-3 w-full">
                  <Button variant="secondary" size="lg" className="w-full" onClick={reset}>
                    <Camera size={17}/> Share More Photos
                  </Button>
                  {event?.settings?.allow_public_view && (
                    <a href={`/e/${token}/gallery`} className="block">
                      <Button variant="ghost" size="lg" className="w-full">
                        <Image size={17}/> View Gallery
                      </Button>
                    </a>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
