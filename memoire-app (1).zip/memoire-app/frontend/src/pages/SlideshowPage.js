import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';
import api from '../utils/api';
import { useEventSocket } from '../hooks/useSocket';

const INTERVAL = 6000; // ms per slide

export default function SlideshowPage() {
  const { token } = useParams();
  const [event,   setEvent]   = useState(null);
  const [photos,  setPhotos]  = useState([]);
  const [idx,     setIdx]     = useState(0);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef(null);

  useEffect(() => {
    Promise.all([
      api.get(`/public/events/${token}`),
      api.get(`/public/events/${token}/gallery?limit=200&type=photo`),
    ]).then(([eRes, pRes]) => {
      setEvent(eRes.data);
      setPhotos(pRes.data.items);
    }).finally(() => setLoading(false));
  }, [token]);

  useEventSocket(event?.id, item => {
    if (item.type === 'photo' || item.type === 'video')
      setPhotos(p => [item, ...p]);
  });

  const advance = useCallback(() =>
    setIdx(p => photos.length ? (p + 1) % photos.length : 0),
  [photos.length]);

  useEffect(() => {
    if (!photos.length) return;
    timerRef.current = setInterval(advance, INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [advance, photos.length]);

  const current = photos[idx];

  if (loading || !current) return (
    <div className="fixed inset-0 bg-[var(--stone-900)] flex flex-col items-center justify-center text-white">
      <motion.div animate={{ scale: [1, 1.1, 1], opacity: [.4, 1, .4] }} transition={{ repeat: Infinity, duration: 2 }}>
        <Heart size={44} className="text-[var(--gold-400)]"/>
      </motion.div>
      <p className="font-display text-2xl mt-5 opacity-60">{event?.title || 'Loading…'}</p>
      {!loading && photos.length === 0 && (
        <p className="text-sm text-white/40 mt-3">Waiting for guests to upload photos…</p>
      )}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-[var(--stone-900)] overflow-hidden">
      {/* Blurred background fill */}
      <AnimatePresence>
        <motion.div key={current.id + '_bg'}
          initial={{ opacity: 0 }} animate={{ opacity: .5 }} exit={{ opacity: 0 }}
          className="absolute inset-0"
          style={{
            backgroundImage: `url(${current.thumbnail_url || current.original_url})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'blur(50px) saturate(1.3)',
            transform: 'scale(1.15)',
          }}
        />
      </AnimatePresence>

      {/* Main photo */}
      <AnimatePresence mode="wait">
        <motion.div key={current.id}
          initial={{ opacity: 0, scale: 1.04 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: .97 }}
          transition={{ duration: .9, ease: [.4,0,.2,1] }}
          className="absolute inset-0 flex items-center justify-center px-16 py-16"
        >
          {current.type === 'video' ? (
            <video src={current.original_url} autoPlay muted loop
              className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl"/>
          ) : (
            <img src={current.original_url} alt=""
              className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl"/>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Top bar */}
      <div className="absolute top-0 inset-x-0 p-7 flex items-center gap-3">
        <Heart size={18} className="text-[var(--gold-400)]"/>
        <span className="font-display text-lg text-white tracking-wide opacity-90">{event?.title}</span>
      </div>

      {/* Uploader tag */}
      <AnimatePresence>
        {current.uploader_name && (
          <motion.div key={current.id + '_name'}
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="absolute bottom-0 inset-x-0 pb-8 flex justify-center">
            <div className="bg-white bg-opacity-12 backdrop-blur-sm text-white text-sm px-5 py-2 rounded-full">
              📸 {current.uploader_name}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress bar */}
      <div className="absolute bottom-0 inset-x-0 h-1">
        <motion.div
          key={current.id}
          className="h-full bg-[var(--gold-400)] origin-left"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: INTERVAL / 1000, ease: 'linear' }}
        />
      </div>

      {/* Counter */}
      <div className="absolute top-7 right-7 text-white/40 text-xs font-medium">
        {idx + 1} / {photos.length}
      </div>
    </div>
  );
}
