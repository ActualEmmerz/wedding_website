import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, LogOut, Camera, Calendar, Settings, Eye, Trash2, Image, Video, MessageSquare } from 'lucide-react';
import { format } from 'date-fns';
import api from '../utils/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Button, Card, Badge, Spinner, Modal, Input, Textarea, Toggle, Empty } from '../components/UI';

/* ── Create Event Modal ─────────────────────────────────────────────────── */
function CreateModal({ open, onClose, onCreate }) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({
    title: '', description: '', starts_at: '', ends_at: '',
    settings: { require_name: true, allow_public_view: true, enable_slideshow: true, primary_color: '#c9a96e' },
  });
  const set = (k) => (e) => setForm(p => ({ ...p, [k]: e.target.value }));
  const setSetting = (k, v) => setForm(p => ({ ...p, settings: { ...p.settings, [k]: v } }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { data } = await api.post('/events', form);
      onCreate(data);
      toast('Event created!', 'success');
      onClose();
      setForm({ title:'',description:'',starts_at:'',ends_at:'', settings:{require_name:true,allow_public_view:true,enable_slideshow:true,primary_color:'#c9a96e'} });
    } catch (err) {
      toast(err.response?.data?.error || 'Failed to create event', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Create New Event">
      <form onSubmit={submit} className="flex flex-col gap-5">
        <Input label="Event title *" placeholder="Sarah & James Wedding" value={form.title} onChange={set('title')} required />
        <Textarea label="Description" placeholder="A note shown to guests on the upload page…" value={form.description} onChange={set('description')} rows={3} />
        <div className="grid grid-cols-2 gap-3">
          <Input label="Start date" type="datetime-local" value={form.starts_at} onChange={set('starts_at')} />
          <Input label="End date"   type="datetime-local" value={form.ends_at}   onChange={set('ends_at')} />
        </div>
        <div className="border border-[var(--stone-100)] rounded-[var(--r-lg)] p-4 flex flex-col gap-3 bg-[var(--stone-50)]">
          <p className="text-xs font-medium text-[var(--stone-500)] uppercase tracking-wider">Settings</p>
          <Toggle checked={form.settings.require_name}      onChange={v => setSetting('require_name',v)}      label="Require guest name" />
          <Toggle checked={form.settings.allow_public_view} onChange={v => setSetting('allow_public_view',v)} label="Allow public gallery view" />
          <Toggle checked={form.settings.enable_slideshow}  onChange={v => setSetting('enable_slideshow',v)}  label="Enable slideshow mode" />
          <div className="flex items-center gap-3">
            <label className="text-sm text-[var(--stone-700)]">Accent colour</label>
            <input type="color" value={form.settings.primary_color}
              onChange={e => setSetting('primary_color', e.target.value)}
              className="w-8 h-8 rounded cursor-pointer border border-[var(--stone-200)]" />
          </div>
        </div>
        <div className="flex gap-3 justify-end pt-1">
          <Button variant="ghost" type="button" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={busy}>Create Event</Button>
        </div>
      </form>
    </Modal>
  );
}

/* ── Event Card ─────────────────────────────────────────────────────────── */
function EventCard({ event, onDelete, onClick }) {
  const publicUrl = `${window.location.origin}/e/${event.upload_token}`;
  return (
    <motion.div layout initial={{ opacity:0,y:16 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0,scale:.96 }}>
      <Card className="p-6 cursor-pointer hover:shadow-[var(--shadow-lg)] transition-shadow group" onClick={onClick}>
        <div className="flex items-start gap-3 mb-4">
          <div className="flex-1 min-w-0">
            <h3 className="font-display text-xl truncate">{event.title}</h3>
            {event.description && (
              <p className="text-sm text-[var(--stone-500)] mt-0.5 line-clamp-2">{event.description}</p>
            )}
          </div>
          <Badge variant={event.is_active ? 'green' : 'default'}>
            {event.is_active ? 'Active' : 'Closed'}
          </Badge>
        </div>

        {/* Stats row */}
        <div className="flex gap-4 mb-5 text-xs text-[var(--stone-400)]">
          <span className="flex items-center gap-1"><Image size={12}/>{event.photo_count ?? 0} photos</span>
          <span className="flex items-center gap-1"><Video size={12}/>{event.video_count ?? 0} videos</span>
          <span className="flex items-center gap-1"><MessageSquare size={12}/>{event.message_count ?? 0}</span>
          <span className="flex items-center gap-1 ml-auto"><Calendar size={12}/>{format(new Date(event.created_at),'MMM d, yyyy')}</span>
        </div>

        <div className="flex gap-2" onClick={e => e.stopPropagation()}>
          <Button variant="secondary" size="sm" onClick={() => window.open(publicUrl,'_blank')}>
            <Eye size={13}/> Preview
          </Button>
          <Button variant="ghost" size="sm" onClick={onClick}>
            <Settings size={13}/> Manage
          </Button>
          <Button variant="ghost" size="sm" className="ml-auto !text-rose-500 hover:!bg-rose-50"
            onClick={() => onDelete(event)}>
            <Trash2 size={13}/>
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}

/* ── Dashboard Page ─────────────────────────────────────────────────────── */
export default function AdminDashboard() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [delTarget, setDelTarget]   = useState(null);
  const { admin, logout } = useAuth();
  const { toast } = useToast();
  const nav = useNavigate();

  useEffect(() => {
    api.get('/events')
      .then(r => setEvents(r.data))
      .catch(() => toast('Failed to load events','error'))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async () => {
    if (!delTarget) return;
    try {
      await api.delete(`/events/${delTarget.id}`);
      setEvents(p => p.filter(e => e.id !== delTarget.id));
      toast('Event deleted','success');
    } catch { toast('Delete failed','error'); }
    setDelTarget(null);
  };

  return (
    <div className="min-h-screen bg-[var(--stone-50)]">
      {/* Header */}
      <header className="bg-white border-b border-[var(--stone-100)] sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center gap-4">
          <h1 className="font-display text-2xl flex-1">Mémoire</h1>
          <span className="text-sm text-[var(--stone-400)] hidden sm:block">{admin?.name || admin?.email}</span>
          <Button variant="ghost" size="sm" onClick={logout}>
            <LogOut size={15}/> Sign out
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl">Your Events</h2>
            <p className="text-[var(--stone-500)] text-sm mt-1">{events.length} event{events.length!==1?'s':''}</p>
          </div>
          <Button size="lg" onClick={() => setShowCreate(true)}>
            <Plus size={18}/> New Event
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-24"><Spinner size={44}/></div>
        ) : events.length === 0 ? (
          <Empty
            icon={Camera}
            title="No events yet"
            body="Create your first event to generate a shareable QR code and start collecting memories."
            action={<Button size="lg" onClick={() => setShowCreate(true)}><Plus size={18}/>Create Event</Button>}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            <AnimatePresence>
              {events.map(ev => (
                <EventCard
                  key={ev.id}
                  event={ev}
                  onDelete={setDelTarget}
                  onClick={() => nav(`/admin/events/${ev.id}`)}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>

      <CreateModal open={showCreate} onClose={() => setShowCreate(false)} onCreate={ev => setEvents(p => [ev,...p])} />

      <Modal open={!!delTarget} onClose={() => setDelTarget(null)} title="Delete Event">
        <p className="text-[var(--stone-600)] mb-6">
          Permanently delete <strong className="text-[var(--stone-900)]">{delTarget?.title}</strong>?
          All photos, videos and messages will be removed.
        </p>
        <div className="flex gap-3 justify-end">
          <Button variant="ghost" onClick={() => setDelTarget(null)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Delete Forever</Button>
        </div>
      </Modal>
    </div>
  );
}
