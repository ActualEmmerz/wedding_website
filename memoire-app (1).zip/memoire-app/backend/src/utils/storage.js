'use strict';
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

// ── Configure S3 client (supports MinIO via env) ─────────────────────────────
const s3Config = {
  accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region:          process.env.AWS_REGION || 'us-east-1',
};

if (process.env.MINIO_ENDPOINT) {
  s3Config.endpoint         = process.env.MINIO_ENDPOINT;
  s3Config.s3ForcePathStyle = process.env.MINIO_USE_PATH_STYLE === 'true';
}

const s3     = new AWS.S3(s3Config);
const BUCKET = process.env.AWS_S3_BUCKET;
const CDN    = process.env.AWS_CLOUDFRONT_URL;

/** Public URL for a stored key */
const getUrl = (key) =>
  CDN
    ? `${CDN.replace(/\/$/, '')}/${key}`
    : `https://${BUCKET}.s3.${process.env.AWS_REGION || 'us-east-1'}.amazonaws.com/${key}`;

/** Upload a Buffer to S3; returns { key, url } */
const putBuffer = async (buffer, mime, prefix = 'uploads') => {
  const ext = mime.split('/')[1]?.replace('jpeg', 'jpg') || 'bin';
  const key = `${prefix}/${uuidv4()}.${ext}`;

  await s3
    .putObject({
      Bucket:       BUCKET,
      Key:          key,
      Body:         buffer,
      ContentType:  mime,
      CacheControl: 'public, max-age=31536000, immutable',
    })
    .promise();

  return { key, url: getUrl(key) };
};

/** Get a readable stream for an S3 object */
const getStream = (key) =>
  s3.getObject({ Bucket: BUCKET, Key: key }).createReadStream();

/** Delete a single object */
const remove = (key) =>
  s3.deleteObject({ Bucket: BUCKET, Key: key }).promise();

/** Generate a time-limited signed URL */
const signedUrl = (key, expiresIn = 3600) =>
  s3.getSignedUrl('getObject', { Bucket: BUCKET, Key: key, Expires: expiresIn });

module.exports = { s3, BUCKET, getUrl, putBuffer, getStream, remove, signedUrl };
