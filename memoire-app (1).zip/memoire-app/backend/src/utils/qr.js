'use strict';
const QRCode = require('qrcode');

/**
 * Generate a QR code PNG buffer
 */
const toBuffer = (url) =>
  QRCode.toBuffer(url, {
    type:                 'png',
    width:                600,
    margin:               2,
    errorCorrectionLevel: 'H',
    color: { dark: '#1c1917', light: '#fffbf7' },
  });

/**
 * Generate a QR code as a base64 data URL (for inline embedding)
 */
const toDataURL = (url) =>
  QRCode.toDataURL(url, {
    width:                600,
    margin:               2,
    errorCorrectionLevel: 'H',
    color: { dark: '#1c1917', light: '#fffbf7' },
  });

module.exports = { toBuffer, toDataURL };
