'use strict';
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

const SQL = `
-- Enable pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── Admins ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          VARCHAR(255),
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Events ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS events (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id       UUID NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  title          VARCHAR(255) NOT NULL,
  slug           VARCHAR(80)  UNIQUE NOT NULL,
  upload_token   VARCHAR(80)  UNIQUE NOT NULL,
  description    TEXT,
  cover_photo_url TEXT,
  starts_at      TIMESTAMPTZ,
  ends_at        TIMESTAMPTZ,
  is_active      BOOLEAN NOT NULL DEFAULT true,
  settings       JSONB   NOT NULL DEFAULT '{}',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_events_admin       ON events(admin_id);
CREATE INDEX IF NOT EXISTS idx_events_token       ON events(upload_token);
CREATE INDEX IF NOT EXISTS idx_events_slug        ON events(slug);

-- ── Media items ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS media_items (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id       UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  uploader_name  VARCHAR(255),
  type           VARCHAR(20)  NOT NULL CHECK (type IN ('photo','video','message')),
  original_url   TEXT,
  thumbnail_url  TEXT,
  mime_type      VARCHAR(100),
  filesize       BIGINT,
  width          INTEGER,
  height         INTEGER,
  duration_secs  FLOAT,
  message_body   TEXT,
  is_approved    BOOLEAN NOT NULL DEFAULT true,
  metadata       JSONB   NOT NULL DEFAULT '{}',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_media_event      ON media_items(event_id);
CREATE INDEX IF NOT EXISTS idx_media_created    ON media_items(event_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_type       ON media_items(event_id, type);
CREATE INDEX IF NOT EXISTS idx_media_approved   ON media_items(event_id, is_approved);

-- ── Access logs ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS access_logs (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id   UUID REFERENCES events(id) ON DELETE CASCADE,
  ip         VARCHAR(45),
  user_agent TEXT,
  action     VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logs_event ON access_logs(event_id, created_at DESC);
`;

(async () => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(SQL);
    await client.query('COMMIT');
    console.log('✅  Database migration complete');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌  Migration failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
})();
