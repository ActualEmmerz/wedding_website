'use strict';
const router      = require('express').Router();
const { v4: uuid} = require('uuid');
const sharp       = require('sharp');
const rateLimit   = require('express-rate-limit');
const db          = require('../utils/db');
const { putBuffer } = require('../utils/storage');
const { upload, MAX_FILES } = require('../middleware/upload');

// Per-upload rate limit
const uploadLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message:  { error: 'Too many requests — please try again later' },
  standardHeaders: true,
  legacyHeaders:   false,
});

/* Lookup event by token */
const getEvent = async (token) => {
  const { rows } = await db.query(
    'SELECT * FROM events WHERE upload_token=$1', [token]
  );
  return rows[0] ?? null;
};

/* Log access (fire-and-forget) */
const log = (eventId, ip, ua, action) =>
  db.query(
    'INSERT INTO access_logs (event_id,ip,user_agent,action) VALUES ($1,$2,$3,$4)',
    [eventId, ip, ua, action]
  ).catch(() => {});

// ── GET /api/public/events/:token ────────────────────────────────────────────
router.get('/events/:token', async (req, res) => {
  try {
    const ev = await getEvent(req.params.token);
    if (!ev) return res.status(404).json({ error: 'Event not found' });

    log(ev.id, req.ip, req.headers['user-agent'], 'view');

    res.json({
      id:              ev.id,
      title:           ev.title,
      description:     ev.description,
      cover_photo_url: ev.cover_photo_url,
      is_active:       ev.is_active,
      starts_at:       ev.starts_at,
      ends_at:         ev.ends_at,
      settings: {
        require_name:       ev.settings.require_name,
        allow_public_view:  ev.settings.allow_public_view,
        enable_slideshow:   ev.settings.enable_slideshow,
        primary_color:      ev.settings.primary_color ?? '#c9a96e',
        theme:              ev.settings.theme ?? 'light',
        language:           ev.settings.language ?? 'en',
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /api/public/events/:token/gallery ────────────────────────────────────
router.get('/events/:token/gallery', async (req, res) => {
  const { cursor, limit = 40, type } = req.query;
  try {
    const ev = await getEvent(req.params.token);
    if (!ev)                           return res.status(404).json({ error: 'Event not found' });
    if (!ev.settings.allow_public_view) return res.status(403).json({ error: 'Gallery is private' });

    let q      = 'SELECT * FROM media_items WHERE event_id=$1';
    const args = [ev.id];

    if (ev.settings.moderation_enabled) q += ' AND is_approved=true';
    if (type)   { args.push(type);   q += ` AND type=$${args.length}`; }
    if (cursor) { args.push(cursor); q += ` AND created_at < (SELECT created_at FROM media_items WHERE id=$${args.length})`; }

    const take = Math.min(parseInt(limit) || 40, 100);
    args.push(take + 1);
    q += ` ORDER BY created_at DESC LIMIT $${args.length}`;

    const { rows } = await db.query(q, args);
    const items     = rows.slice(0, take);
    const nextCursor = rows.length > take ? items[items.length - 1]?.id : null;

    res.json({ items, next_cursor: nextCursor });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /api/public/events/:token/media ─────────────────────────────────────
router.post(
  '/events/:token/media',
  uploadLimiter,
  upload.array('files', MAX_FILES),
  async (req, res) => {
    try {
      const ev = await getEvent(req.params.token);
      if (!ev)         return res.status(404).json({ error: 'Event not found' });
      if (!ev.is_active) return res.status(403).json({ error: 'This event is no longer accepting uploads' });

      const now = new Date();
      if (ev.ends_at && new Date(ev.ends_at) < now)
        return res.status(403).json({ error: 'This event has ended' });

      const { uploader_name, message } = req.body;
      const name = uploader_name?.trim() || 'Guest';

      if (ev.settings.require_name && !uploader_name?.trim())
        return res.status(400).json({ error: 'Your name is required to upload' });

      const saved = [];

      // ── Text message ──────────────────────────────────────────────────────
      if (message?.trim()) {
        const { rows } = await db.query(
          `INSERT INTO media_items (event_id, uploader_name, type, message_body)
           VALUES ($1,$2,'message',$3) RETURNING *`,
          [ev.id, name, message.trim()]
        );
        saved.push(rows[0]);
      }

      // ── File uploads ──────────────────────────────────────────────────────
      for (const file of req.files ?? []) {
        const isImage = file.mimetype.startsWith('image/');
        const isVideo = file.mimetype.startsWith('video/');

        let originalUrl   = null;
        let thumbnailUrl  = null;
        let width = null, height = null;

        // Upload original
        const { url: origUrl } = await putBuffer(
          file.buffer, file.mimetype, `events/${ev.id}/originals`
        );
        originalUrl = origUrl;

        // Generate thumbnail for images
        if (isImage) {
          try {
            const meta    = await sharp(file.buffer).metadata();
            width  = meta.width;
            height = meta.height;

            const thumbBuf = await sharp(file.buffer)
              .resize(900, 900, { fit: 'inside', withoutEnlargement: true })
              .jpeg({ quality: 82, progressive: true })
              .toBuffer();

            const { url: thumbUrl } = await putBuffer(thumbBuf, 'image/jpeg', `events/${ev.id}/thumbs`);
            thumbnailUrl = thumbUrl;
          } catch (e) {
            console.warn('Thumbnail failed:', e.message);
            thumbnailUrl = originalUrl;
          }
        }

        const { rows } = await db.query(
          `INSERT INTO media_items
             (event_id, uploader_name, type, original_url, thumbnail_url,
              mime_type, filesize, width, height)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           RETURNING *`,
          [ev.id, name, isImage ? 'photo' : 'video',
           originalUrl, thumbnailUrl,
           file.mimetype, file.size, width, height]
        );
        saved.push(rows[0]);
      }

      if (!saved.length)
        return res.status(400).json({ error: 'Nothing was uploaded' });

      // Emit realtime
      const io = req.app.get('io');
      if (io) saved.forEach(item => io.to(`ev:${ev.id}`).emit('media_created', item));

      log(ev.id, req.ip, req.headers['user-agent'], 'upload');
      res.status(201).json({ ok: true, items: saved });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: err.message || 'Upload failed' });
    }
  }
);

module.exports = router;
