'use strict';
const router   = require('express').Router();
const crypto   = require('crypto');
const archiver = require('archiver');
const db       = require('../utils/db');
const { getStream, putBuffer } = require('../utils/storage');
const { toDataURL }            = require('../utils/qr');
const { authenticate }         = require('../middleware/auth');

const rand    = (n) => crypto.randomBytes(n).toString('hex');
const pubUrl  = (token) => `${process.env.APP_URL}/e/${token}`;

/* helper – verify event belongs to calling admin */
const ownEvent = async (adminId, eventId) => {
  const { rows } = await db.query(
    'SELECT * FROM events WHERE id=$1 AND admin_id=$2',
    [eventId, adminId]
  );
  return rows[0] || null;
};

// ── POST /api/events ─────────────────────────────────────────────────────────
router.post('/', authenticate, async (req, res) => {
  const { title, description, starts_at, ends_at, settings = {} } = req.body;
  if (!title?.trim()) return res.status(400).json({ error: 'Title is required' });

  const defaults = {
    require_name:        true,
    allow_public_view:   true,
    enable_slideshow:    true,
    moderation_enabled:  false,
    theme:               'light',
    primary_color:       '#c9a96e',
    language:            'en',
  };

  try {
    const { rows } = await db.query(
      `INSERT INTO events
         (admin_id, title, slug, upload_token, description, starts_at, ends_at, settings)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [
        req.admin.id,
        title.trim(),
        rand(5),
        rand(16),
        description?.trim() || null,
        starts_at || null,
        ends_at   || null,
        JSON.stringify({ ...defaults, ...settings }),
      ]
    );

    const ev = rows[0];
    const public_url    = pubUrl(ev.upload_token);
    const qr_data_url   = await toDataURL(public_url);

    res.status(201).json({ ...ev, public_url, qr_data_url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /api/events ──────────────────────────────────────────────────────────
router.get('/', authenticate, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT e.*,
         COUNT(m.id)::int                                           AS media_count,
         COUNT(m.id) FILTER (WHERE m.type='photo')::int             AS photo_count,
         COUNT(m.id) FILTER (WHERE m.type='video')::int             AS video_count,
         COUNT(m.id) FILTER (WHERE m.type='message')::int           AS message_count
       FROM events e
       LEFT JOIN media_items m ON m.event_id = e.id
       WHERE e.admin_id = $1
       GROUP BY e.id
       ORDER BY e.created_at DESC`,
      [req.admin.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /api/events/:id ──────────────────────────────────────────────────────
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT e.*,
         COUNT(m.id)::int                                           AS media_count,
         COUNT(m.id) FILTER (WHERE m.type='photo')::int             AS photo_count,
         COUNT(m.id) FILTER (WHERE m.type='video')::int             AS video_count,
         COUNT(m.id) FILTER (WHERE m.type='message')::int           AS message_count
       FROM events e
       LEFT JOIN media_items m ON m.event_id = e.id
       WHERE e.id=$1 AND e.admin_id=$2
       GROUP BY e.id`,
      [req.params.id, req.admin.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Event not found' });

    const ev = rows[0];
    const public_url  = pubUrl(ev.upload_token);
    const qr_data_url = await toDataURL(public_url);
    res.json({ ...ev, public_url, qr_data_url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PUT /api/events/:id ──────────────────────────────────────────────────────
router.put('/:id', authenticate, async (req, res) => {
  try {
    const current = await ownEvent(req.admin.id, req.params.id);
    if (!current) return res.status(404).json({ error: 'Event not found' });

    const {
      title       = current.title,
      description = current.description,
      starts_at   = current.starts_at,
      ends_at     = current.ends_at,
      is_active   = current.is_active,
      settings    = {},
    } = req.body;

    const merged = { ...current.settings, ...settings };

    const { rows } = await db.query(
      `UPDATE events
       SET title=$1, description=$2, starts_at=$3, ends_at=$4,
           is_active=$5, settings=$6, updated_at=NOW()
       WHERE id=$7 AND admin_id=$8
       RETURNING *`,
      [title, description, starts_at, ends_at, is_active,
       JSON.stringify(merged), req.params.id, req.admin.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE /api/events/:id ───────────────────────────────────────────────────
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(404).json({ error: 'Event not found' });
    await db.query('DELETE FROM events WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /api/events/:id/media ────────────────────────────────────────────────
router.get('/:id/media', authenticate, async (req, res) => {
  const { page = 1, limit = 100, type } = req.query;
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(404).json({ error: 'Event not found' });

    let q = 'SELECT * FROM media_items WHERE event_id=$1';
    const params = [req.params.id];
    if (type) { params.push(type); q += ` AND type=$${params.length}`; }
    q += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));

    const { rows } = await db.query(q, params);
    const total = (await db.query(
      'SELECT COUNT(*)::int FROM media_items WHERE event_id=$1', [req.params.id]
    )).rows[0].count;

    res.json({ items: rows, total, page: +page, limit: +limit });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PATCH /api/events/:id/media/:mid ─────────────────────────────────────────
router.patch('/:id/media/:mid', authenticate, async (req, res) => {
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(403).json({ error: 'Forbidden' });

    const { rows } = await db.query(
      `UPDATE media_items SET is_approved=$1
       WHERE id=$2 AND event_id=$3 RETURNING *`,
      [req.body.is_approved, req.params.mid, req.params.id]
    );
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE /api/events/:id/media/:mid ────────────────────────────────────────
router.delete('/:id/media/:mid', authenticate, async (req, res) => {
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(403).json({ error: 'Forbidden' });
    await db.query('DELETE FROM media_items WHERE id=$1 AND event_id=$2', [req.params.mid, req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /api/events/:id/download ────────────────────────────────────────────
router.post('/:id/download', authenticate, async (req, res) => {
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(404).json({ error: 'Event not found' });

    const { rows } = await db.query(
      `SELECT * FROM media_items
       WHERE event_id=$1 AND type IN ('photo','video')
       ORDER BY created_at ASC`,
      [req.params.id]
    );

    const safe = ev.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${safe}_photos.zip"`);

    const archive = archiver('zip', { zlib: { level: 1 } });
    archive.on('error', (e) => { console.error('Archive error', e); res.end(); });
    archive.pipe(res);

    for (const item of rows) {
      if (!item.original_url) continue;
      try {
        const urlObj  = new URL(item.original_url);
        const key     = decodeURIComponent(urlObj.pathname.replace(/^\//, ''));
        const ext     = item.mime_type?.split('/')[1]?.replace('jpeg','jpg') || 'jpg';
        const name    = `${(item.uploader_name || 'guest').replace(/\s+/g,'_')}_${item.id.slice(0,8)}.${ext}`;
        archive.append(getStream(key), { name });
      } catch (e) {
        console.error('Skipping file:', e.message);
      }
    }

    await archive.finalize();
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.status(500).json({ error: 'Download failed' });
  }
});

// ── GET /api/events/:id/qr ───────────────────────────────────────────────────
router.get('/:id/qr', authenticate, async (req, res) => {
  try {
    const ev = await ownEvent(req.admin.id, req.params.id);
    if (!ev) return res.status(404).json({ error: 'Event not found' });
    const public_url  = pubUrl(ev.upload_token);
    const qr_data_url = await toDataURL(public_url);
    res.json({ public_url, qr_data_url });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
